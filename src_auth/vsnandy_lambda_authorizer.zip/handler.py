def handler(event, context):
    response = {
        "statusCode": 204
    }

    return response